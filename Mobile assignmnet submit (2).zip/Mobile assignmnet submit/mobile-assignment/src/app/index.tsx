import React from 'react';
import {Text, View, StyleSheet, StatusBar, Image, ScrollView, Alert, Button } from 'react-native';
import { Stack } from 'expo-router';

export default function Index() {
  return (
    <ScrollView style={styles.container}>
      <Stack.Screen options={{ headerShown: false }}/>
      <StatusBar barStyle="light-content" backgroundColor="#0056b3" />
      
      <View style={styles.blueBox}>
        <Image source={require('@/assets/images/BackDropImage.png')} style={styles.myOtherImage}/>
      </View>

      <View style={styles.greyCircle}>
        <Image source={require('@/assets/images/TrashCan.jpg')} style={styles.myImage}/>
      </View>
      
      <View>
        <Image source={require('@/assets/images/GenderIcon.png')} style={styles.genderIcon}/>
      </View>
        

      <View style={styles.editSquare}>
        <Text style={styles.editText}>Edit</Text>
      </View>

      <View style={styles.Name}>
        <Text style={styles.nameColor}>Orion_the_boi</Text>
      </View>

      <View style={styles.ID}>
        <Text style={styles.idColor}>
          Account ID: 359626130</Text>
      </View>

      <View style={styles.DefaultSig}>
        <Text style={styles.defaultSigColor}>Default signiture given to everyone~</Text>
      </View>


      {/*Post, Following, Followers, Likes*/}
      <View style={styles.Hold}>
      <View style={styles.stat}>
        <Text style={styles.value}>0</Text>
        <Text style={styles.label}>Posts</Text>
      </View>

      <View style={styles.stat}>
        <Text style={styles.value}>0</Text>
        <Text style={styles.label}>Following</Text>
      </View>

      <View style={styles.stat}>
        <Text style={styles.value}>0</Text>
        <Text style={styles.label}>Followers</Text>
      </View>

      <View style={styles.stat}>
        <Text style={styles.value}>1</Text>
        <Text style={styles.label}>Likes</Text>
      </View>
    </View>


    {/*Two Big Cyan Boxes*/}
    <View style={styles.row}>
      <View style={styles.box}>
        <Text style={styles.text}>Creator LAB</Text>
      </View>

      <View style={styles.box}>
        <Text style={styles.text}>Craftspeople Center</Text>
      </View>
    </View>

    <View style={styles.card}>
      <View style={styles.topSection}>
        <Image
          source={require('@/assets/images/PinkHairedGirl.jpg')} 
          style={styles.avatar}
        />
        <View style={styles.nameContainer}>
          <View style={styles.nameRow}>
            <Text style={styles.name}>Akivili</Text>
            <View style={styles.levelBadge}>
              <Text style={styles.levelText}>Lv. 70</Text>
            </View>
          </View>
          <Text style={styles.server}>America Server</Text>
        </View>
      </View>



      {/*The Big Status Block*/}
      <View style={styles.statsRow}>
        <View style={styles.status}>
          <Text style={styles.statValue}>388</Text>
          <Text style={styles.statLabel}>Time Active</Text>
        </View>

        <View style={styles.status}>
          <Text style={styles.statValue}>993</Text>
          <Text style={styles.statLabel}>Achievements{'\n'}Unlocked</Text>
        </View>

        <View style={styles.status}>
          <Text style={styles.statValue}>52</Text>
          <Text style={styles.statLabel}>Characters{'\n'}Unlocked</Text>
        </View>

        <View style={styles.status}>
          <Text style={styles.statValue}>1663</Text>
          <Text style={styles.statLabel}>Treasures{'\n'}Opened</Text>
        </View>
      </View>
    </View>


    {/*Post, Comments, Favorites, Topics, Viewed*/}
    <View style={styles.Socials}>
      <View style={styles.Soc}>
        <Text style={[styles.als, { fontWeight: 'bold', color: 'white'}]}>Posts</Text>
      </View>

      <View style={styles.Soc}>
        <Text style={styles.als}>Comments</Text>
      </View>

      <View style={styles.Soc}>
        <Text style={styles.als}>Favorites</Text>
      </View>

      <View style={styles.Soc}>
        <Text style={styles.als}>Topics</Text>
      </View>

      <View style={styles.Soc}>
        <Text style={styles.als}>Viewed</Text>
      </View>
    </View>


    {/*Game Tabs*/}
    <View style={styles.Tab}>
  <View style={[styles.game, styles.selectedGame]}>
    <Text style={[styles.gameName, styles.selectedText]}>All</Text>
  </View>

  <View style={styles.game}>
    <Text style={styles.gameName}>Genshin Impact</Text>
  </View>

  <View style={styles.game}>
    <Text style={styles.gameName}>Honkai: Star Rail</Text>
  </View>

  <View style={styles.game}>
    <Text style={styles.gameName}>Zenless Zone Zero</Text>
  </View>
</View>

{/*Blue Cat*/}
<View style={styles.BlueCat}>
  <Image source={require('@/assets/images/BlueCat.jpg')} style={styles.bluecatImage}/>
</View>


{/*Alert Button */}
<View style={styles.alertButtonContainer}>
  <Button title="Alert" onPress={() => Alert.alert('Alert Button pressed')}/>
</View>
  
</ScrollView>
  
  );  
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000000', 
  },
  blueBox: {
    width: '100%',             
    height: 100,                 
  },
  greyCircle: {
    position: 'absolute',
    top: 50,
    left: 20,
    width: 150,
    height: 150,
    borderRadius: 100,
  },
  editSquare: {
    position: 'absolute',
    top: 120,
    right: 30,
    width: 90,
    height: 50,
    borderRadius: 40,
    backgroundColor: 'black',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'blue',
  },
  editText: {
    color: 'blue',
    fontWeight: 'bold',
    fontSize: 20,
  },
  myImage: {
    flex: 1,
    width: 150,
    height: 150,
    borderRadius: 100,
  },
  genderIcon:{
    flex: 1,
    width: 30,
    height: 30,
    borderRadius: 100,
    left: 130,
    top: 60,
  },
  myOtherImage: {
    flex: 1,
    width: '100%',             
    height: 100,  
  },
  Name: {
    top: 110,
    left: 30,
  },
  nameColor: {
    color: 'white',
    fontSize: 30,
    fontWeight: 'bold',
  },
  ID: {
    top: 130,
    left: 30,
  },
  idColor: {
    color: 'white',
  },
  DefaultSig: {
    top: 140,
    left: 30,
  },
  defaultSigColor: {
    color: 'grey',
  },


  //Post, Following, Followrs, Likes
  Hold: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    top: 180,
  },
  stat: {
    alignItems: 'center',
  },
  value: {
    color: 'white',
    fontSize: 22,
    fontWeight: 'bold',
  },
  label: {
    color: '#aaa',
    fontSize: 13,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 10,
    top: 220,
  },

  //Two Big Cyan Boxes
  box: {
    flex: 1,
    backgroundColor: '#6B8CFF',
    borderRadius: 20,
    paddingVertical: 16,
    paddingHorizontal: 18,
    marginHorizontal: 6,
    justifyContent: 'center',
    height: 100,
  },
  text: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  card: {
    backgroundColor: '#1a1a2e',
    borderRadius: 20,
    overflow: 'hidden',
    margin: 10,
    top: 250,
  },


  //The Big Status Block
  topSection: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#16213e',
    padding: 14,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
  },
  avatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    marginRight: 12,
  },
  nameContainer: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  name: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    marginRight: 8,
  },
  levelBadge: {
    backgroundColor: '#f0a500',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  levelText: {
    color: 'white',
    fontSize: 12,
    fontWeight: '600',
  },
  server: {
    color: '#aaa',
    fontSize: 13,
    marginTop: 2,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 20,
    paddingHorizontal: 10,
  },
  status: {
    alignItems: 'center',
    flex: 1,
  },
  statValue: {
    color: 'white',
    fontSize: 22,
    fontWeight: '600',
    marginBottom: 4,
  },
  statLabel: {
    color: '#aaa',
    fontSize: 12,
    textAlign: 'center',
  },


  
  //Post, Comments, Favorites, Topics, Viewed
  Socials:{
    flexDirection: 'row',
    justifyContent: 'space-around',
    top: 300,
  },
  Soc:{
    alignItems: 'center',
  },
  als:{
    color: 'grey',
    fontSize: 20,
  },


  //Game Tabs
 Tab: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    top: 350,
  },
  game: {
    flex: 1,
    backgroundColor: '#2a2a3a',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 30,
    marginRight: 10,
    height: 70,
    width: 200,
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedGame: {
    backgroundColor: '#34348a',
  },
  gameName: {
    color: '#aaa',
    fontSize: 20,
    textAlign: 'center',
  },
  selectedText: {
    color: '#7272e0',
    fontWeight: 'bold',
  },

  //BlueCat
  BlueCat:{
    flex: 1,
    top: 360,
    alignItems: 'center',
  },
  bluecatImage:{
    height: 500,
    width: 500,
  },

  //Button
  alertButtonContainer: {
    top: 340,
    marginHorizontal: 30,
    marginBottom: 60, 
  },
});